<?php defined('_JEXEC') or die;

class plgSystemuikit3 extends JPlugin {
	function __construct(&$subject, $config) {
		parent::__construct($subject, $config);
		$this->loadLanguage();
	}

	function onAfterInitialise() {

		$document = JFactory::getDocument();

		if($this->params->get('uikit') == 1) {
			$document->addScript(JURI::base(). "plugins/system/uikit3/js/uikit.min.js");
			$document->addScript(JURI::base(). "plugins/system/uikit3/js/uikit-icon.min.js");
			$document->addStyleSheet(JURI::base(). "plugins/system/uikit3/css/uikit.min.css");
		}

		else {
			$document->addScript('https://cdn.jsdelivr.net/npm/uikit@3/dist/js/uikit.min.js');
			$document->addScript('https://cdn.jsdelivr.net/npm/uikit@3/dist/js/uikit-icons.min.js');
			$document->addStyleSheet('https://cdn.jsdelivr.net/npm/uikit@3/dist/css/uikit.min.css');
		}

	}
}


